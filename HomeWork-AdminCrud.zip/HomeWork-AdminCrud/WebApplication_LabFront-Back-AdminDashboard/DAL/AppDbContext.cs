﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication_Front_Back_AdminDashboard.Models;
using WebApplication_LabFront_Back_AdminDashboard.Models;

namespace WebApplication_LabFront_Back_AdminDashboard.DAL
{
    public class AppDbContext:DbContext
{
        public AppDbContext(DbContextOptions<AppDbContext>options):base(options)
        {

        }

        public DbSet<WhatWeDo> WhatWeDos { get; set; }

        public DbSet<Service> Services { get; set; }
    }
}
