﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication_Front_Back_AdminDashboard.Models
{
    public class Service
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Input is empty"), StringLength(200, ErrorMessage = "It cannot contain more than 200 characters")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Input is empty"), StringLength(250, ErrorMessage = "It cannot contain more than 200 characters")]
        public string Description { get; set; }
        [Required, StringLength(200)]
        public string Icon { get; set; }
    }
}
