﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication_LabFront_Back_AdminDashboard.Models
{
    public class WhatWeDo
 {
        public int Id { get; set; }
        [Required(ErrorMessage ="Input is empty"),StringLength(200,ErrorMessage = "It cannot contain more than 200 characters")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Input is empty"),StringLength(300, ErrorMessage = "It cannot contain more than 300 characters")]
        public string Describtion { get; set; }


    }
}
