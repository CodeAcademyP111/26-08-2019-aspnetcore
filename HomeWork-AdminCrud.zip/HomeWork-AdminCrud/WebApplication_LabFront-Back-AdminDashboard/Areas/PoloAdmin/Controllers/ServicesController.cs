﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication_Front_Back_AdminDashboard.Models;
using WebApplication_LabFront_Back_AdminDashboard.DAL;

namespace WebApplication_Front_Back_AdminDashboard.Areas.PoloAdmin.Controllers
{
    [Area("PoloAdmin")]
    public class ServicesController : Controller
    {
      private  AppDbContext _context;
        public ServicesController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            return View(_context.Services);
        }

        public async Task< IActionResult> Detail(int? id)
        {
            if (id == null) return NotFound();
            Service work = await _context.Services.FindAsync(id);
            if (work == null) return NotFound();

            return View(work);
        }

        public  IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Service work)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }
            await _context.Services.AddAsync(work);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult>Delete(int? id)
        {
            if (id == null) return NotFound();
            Service work = await _context.Services.FindAsync(id);
            if (work == null) return NotFound();

            return View(work);
        }
        [HttpPost]
        [ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteItem(int? id)
        {
            Service work = await _context.Services.FindAsync(id);
            _context.Services.Remove(work);
            await _context.SaveChangesAsync();
          return  RedirectToAction(nameof(Index));

        }

        public async Task<IActionResult>Update(int? id)
        {
            if (id == null) return NotFound();
            Service work = await _context.Services.FindAsync(id);
            if (work == null) return NotFound();

            return View(work);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult>Update(int? id,Service work)
        {
            //Service dbWork =await _context.Services.FindAsync(id);
            //dbWork.Title = work.Title;
            //dbWork.Description = work.Description;
            //dbWork.Icon = work.Icon;
            _context.Entry(work).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));

        }


    }
}