﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication_Front_Back_AdminDashboard.Areas.PoloAdmin.Controllers
{[Area("PoloAdmin")]
    public class FontAwesomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}